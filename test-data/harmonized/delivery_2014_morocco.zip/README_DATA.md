# MODIS -> VIIRS harmonised fires, North Africa 2014

Generated 2026-11-15 03:19 UTC by harmonizer-final (model B logistic + FRP factor
k = 0.575). Aqua MODIS C6.1 day passes; regions: Morocco;
gas flares / static sources removed. Days processed: 365.

- `cells/year=2014/month=MM/part-0.parquet` : one row per 500 m cell (EPSG:3035 grid), Hive partitions.
  Same content in `cells_frp_2014.parquet`. Geometry: `wkt` (WGS84 polygon), `cell_lon` / `cell_lat` centre.
  Key columns: `p_viirs` (probability VIIRS 375 m detects fire), `detect_f1` (p >= 0.167),
  `frp_cell_mw`, `frp_group_viirs_eq_mw`, `region`, `time_utc`, `fire_id`.
- `fires_2014.parquet` : one row per fire group (8-connected MODIS fire pixels of one pass).
- `daily_summary_2014.csv` : per day and region.
- `accuracy_2014.json` : comparison with S-NPP VIIRS (2012+; VIIRS is never a model input).
- `schema.json` : column types.

Rows: 444 cells, 59 fires, 47 MODIS passes.
Limits: day passes only; FRP per cell is indicative (group totals are the reliable quantity); fires missed by
MODIS are not recovered; validated on North Africa 2018 and 2023.
